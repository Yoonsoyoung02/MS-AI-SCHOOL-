const btnstart = document.querySelector("button");
btnstart.onclick = function () {
  alert("start");
};
